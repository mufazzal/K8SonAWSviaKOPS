var AWS = require('aws-sdk');
AWS.config.update({region: 'us-east-1'});
var ec2 = new AWS.EC2({apiVersion: '2016-11-15'});

var create = async (launchTemplateName) => {

var instanceParams = {
  LaunchTemplate: {
      LaunchTemplateName: launchTemplateName
  }, 
  MinCount: 1,
  MaxCount: 1
};

var instancePromiseOut = ec2.runInstances(instanceParams).promise();
return instancePromiseOut
   
}

module.exports = create
