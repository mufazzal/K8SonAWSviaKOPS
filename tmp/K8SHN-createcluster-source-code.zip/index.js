const create = require('./create') 
exports.createCluster = async (event, context) => {
    let response = null;
    
    console.log("event", event)
    
    // let createClusterData = null
    // if(event.body)
    //     createClusterData = JSON.parse(event.body).createClusterData
    // else throw "Invalid request: No createClusterData specify in request"

    // console.log("create cluster data----->", createClusterData)    

    // const launchTemplateName = createClusterData.launchTemplateName ? createClusterData.launchTemplateName : ''
    const launchTemplateName = process.env.launchTemplateName

    let out = {}
    let httpStatusCode = 0;
    try {
        response = await create(launchTemplateName);
        httpStatusCode = 200
        out = {
            success: true,
            response
        }
    } catch (err) {
        console.log(err)
        httpStatusCode = 401
        out = {success: false, error: err, errorMessage: 
            `Something went wrong in Lambda function: ${context.functionName}:${context.functionVersion}`}
    }

    return {
        "isBase64Encoded": false,
        "statusCode": httpStatusCode,
        "headers": { "anykey": "anyValue" },
        "multiValueHeaders": { },
        "body": JSON.stringify(out)
    }
};
