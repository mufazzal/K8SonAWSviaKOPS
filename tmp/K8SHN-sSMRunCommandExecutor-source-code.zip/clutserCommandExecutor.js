'use strict'

const AWS = require('aws-sdk')
const ssm = new AWS.SSM()
var ec2 = new AWS.EC2({apiVersion: '2016-11-15'});

var clutserCommandExecutor = async (ssmDocName, commandToRunForTypeAnyCommand, outputS3BucketName, ssmCommandOutputS3CommonPrefix) => {
  let instanceId = null
  let timeString = new Date();
  timeString = `${timeString.getDate()}-${timeString.getMonth()}-${timeString.getFullYear()}:${timeString.getHours()}:${timeString.getMinutes()}:${timeString.getSeconds()}`
  const outputS3Prefix = `${ssmCommandOutputS3CommonPrefix}/${ssmDocName}/${timeString}/`
  
  var params1 = {
    Filters: [
      {
        'Name': 'tag:Name',
        'Values': ['K8S_INSTALLER-hn.k8shn.com']
      },
      {
        'Name': 'instance-state-name',
        'Values': ['running']
      },      
    ],
    MaxResults: '10'
  };

  await ec2.describeInstances(params1).promise()
    .then(res => {
      instanceId = res.Reservations[0].Instances[0].InstanceId
      console.log(`Candidate Instance: ${instanceId}, SSM Rum Command: ${ssmDocName}, Output: S3:${outputS3BucketName}:${outputS3Prefix}`)
    }).catch(err => {
      console.log('err--->', err)
    })

  const params = {
    DocumentName: ssmDocName,
    InstanceIds: [ instanceId ],
    TimeoutSeconds: 3600,
    OutputS3BucketName: outputS3BucketName,
    OutputS3KeyPrefix: outputS3Prefix,
    OutputS3Region: 'us-east-1'    
  }

  if(ssmDocName === 'AnyCommand') {
    params.Parameters = {
      'Command': [
        commandToRunForTypeAnyCommand,
      ],
    }
  }

  const cmdOut = await ssm.sendCommand(params).promise()
    .then(res => {
      console.log(res)
      const outputPath = `https://${outputS3BucketName}.s3.us-east-1.amazonaws.com/${outputS3Prefix}${res.Command.CommandId}/${instanceId}/awsrunShellScript/script_0/stdout`
      const outputErrPath = `https://${outputS3BucketName}.s3.us-east-1.amazonaws.com/${outputS3Prefix}${res.Command.CommandId}/${instanceId}/awsrunShellScript/script_0/stderr`
      return {
        sucess: true,
        outputPath: outputPath,
        outputErrPath: outputErrPath,
        commsndRunResult: res
      }
    }).catch(err => {
      console.log(err)
      return err
    })
  return cmdOut
}
module.exports = clutserCommandExecutor
