const clutserCommandExecutor = require('./clutserCommandExecutor') 
exports.clutserCommandExecutor = async (event, context) => {
    let response = null;
    
    console.log("event", event)
    
    let commandToRunForTypeAnyCommand = null, clusterId = null, ssmDocName = null, outputS3BucketName = null, ssmCommandOutputS3CommonPrefix = null
    if(event.queryStringParameters.clusterId)
        clusterId = event.queryStringParameters.clusterId
    if(event.queryStringParameters.ssmDocName)
        ssmDocName = event.queryStringParameters.ssmDocName
    if(event.queryStringParameters.outputS3BucketName)
        outputS3BucketName = event.queryStringParameters.outputS3BucketName    
    if(event.queryStringParameters.commandToRunForTypeAnyCommand)
        commandToRunForTypeAnyCommand = event.queryStringParameters.commandToRunForTypeAnyCommand    

    ssmCommandOutputS3CommonPrefix = "workspace/ssmCommandOutputs"

    if(!ssmDocName)
        throw "Invalid request: No instanceId or ssmDocName specify in request"

    console.log("Get Cluster data----->", ssmDocName)    

    let out = {}
    let httpStatusCode = 0;
    try {
        response = await clutserCommandExecutor(ssmDocName, commandToRunForTypeAnyCommand, outputS3BucketName, ssmCommandOutputS3CommonPrefix);
        httpStatusCode = 200
        out = {
            success: true,
            response
        }
    } catch (err) {
        console.log(err)
        httpStatusCode = 401
        out = {success: false, error: err, errorMessage: 
            `Something went wrong in Lambda function: ${context.functionName}:${context.functionVersion}`}
    }

    return {
        "isBase64Encoded": false,
        "statusCode": httpStatusCode,
        "multiValueHeaders": { },
        "body": JSON.stringify(out),
        "headers": {
            "Access-Control-Allow-Credentials": true,
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
        },
    }
};
